﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Graphics_project_zuma
{
    class BezCurve
    {
        public List<PointF> LCtrPts = new List<PointF>();
        float Fact(int v)
        {
            float F = 1;
            for (int i = 2; i <= v; i++)
            {
                F *= i;
            }
            return F;
        }
        PointF CalcCurvePointAtTime(float t)
        {
            PointF P = new PointF();
            int n = LCtrPts.Count - 1;
            float C;
            for (int i = 0; i < LCtrPts.Count; i++)
            {
                C = Fact(n) / (Fact(i) * Fact(n - i));
                P.X += (float)(Math.Pow(t, i) * Math.Pow(1 - t, n - i) * C * LCtrPts[i].X);
                P.Y += (float)(Math.Pow(t, i) * Math.Pow(1 - t, n - i) * C * LCtrPts[i].Y);
            }
            return P;
        }
        public int GiveMeY_At_X(int x)
        {
            for (float t = 0; t <= 1; t += 0.001f)
            {
                PointF P = CalcCurvePointAtTime(t);
                if (Math.Round(P.X) == x)
                {
                    return (int)P.Y;
                }
            }
            return -1;
        }
        public void DrawYourSelf(Graphics g)
        {
            

            for (float t = 0; t <= 1; t += 0.001f)
            {
                PointF P = CalcCurvePointAtTime(t);
                g.FillEllipse(Brushes.Red, P.X - 5, P.Y - 5, 5, 5);
            }
        }
    }
    public class LineSeg
    {
        public PointF PS, PE;

        public void RotateYourSelf(float Xr, float Yr, float th)
        {
            PS.X -= Xr;
            PS.Y -= Yr;
            double nX, nY;
            nX = PS.X * Math.Cos(th) - PS.Y * Math.Sin(th);
            nY = PS.X * Math.Sin(th) + PS.Y * Math.Cos(th);
            PS.X = (float)nX + Xr;
            PS.Y = (float)nY + Yr;

            PE.X -= Xr;
            PE.Y -= Yr;
            nX = PE.X * Math.Cos(th) - PE.Y * Math.Sin(th);
            nY = PE.X * Math.Sin(th) + PE.Y * Math.Cos(th);
            PE.X = (float)nX + Xr;
            PE.Y = (float)nY + Yr;
        }
        public void DrawYourSelf(Graphics g)
        {
            Pen Pn = new Pen(Color.Yellow, 3);
            g.DrawLine(Pn, PS, PE);
            g.FillEllipse(Brushes.Red, PS.X - 5, PS.Y - 5, 10, 10);
            g.FillEllipse(Brushes.Red, PE.X - 5, PE.Y - 5, 10, 10);
        }

    }
    public class ball
    {
        public Color cl;
        public float t;
        public PointF points;
    }
    public partial class Form1 : Form
    {
        Bitmap off;
        List<LineSeg> LRArm_1 = new List<LineSeg>();
        BezCurve l = new BezCurve();
        List<ball> b = new List<ball>();
        Timer t = new Timer();
        
        public Form1()
        {
            this.WindowState = FormWindowState.Maximized;
            this.Load += new EventHandler(Form1_Load);
            this.Paint += new PaintEventHandler(Form1_Paint);
            this.MouseMove += new MouseEventHandler(Form1_MouseMove);
            this.MouseDown += new MouseEventHandler(Form1_MouseDown);
            this.KeyDown += new KeyEventHandler(Form1_KeyDown);
            t.Tick += new EventHandler(t_Tick);
            
            t.Interval = 60;
            t.Start();
            
        }

        float Fact(int v)
        {
            float F = 1;
            for (int i = 2; i <= v; i++)
            {
                F *= i;
            }
            return F;
        }
        float tt = 0;
        float time=0;
        int countstop=0;
        int gameover = 0;
        PointF CalcCurvePointAtTime(float t)
        {
            PointF P = new PointF();
            int n = l.LCtrPts.Count - 1;
            float C;
            for (int i = 0; i < l.LCtrPts.Count; i++)
            {
                C = Fact(n) / (Fact(i) * Fact(n - i));
                P.X += (float)(Math.Pow(t, i) * Math.Pow(1 - t, n - i) * C * l.LCtrPts[i].X);
                P.Y += (float)(Math.Pow(t, i) * Math.Pow(1 - t, n - i) * C * l.LCtrPts[i].Y);
            }
            return P;
        }
        void t_Tick(object sender, EventArgs e)
        {
            DrawDubb(this.CreateGraphics());
            if (move)
            {
                if (countstop % 6==0 && countstop<200)
                {
                    ball pnn = new ball();
                    pnn.points = CalcCurvePointAtTime(0);
                    pnn.t = 0;
                    pnn.cl = Colors[rr.Next(0, 4)];
                    b.Add(pnn);
                }
                
                for (int i = 0; i < b.Count; i++)
                {
                    if (b[0].t >= 1)
                    {
                        move = false;
                        gameover = 1;
                    }
                    b[i].t+=0.003f;
                    b[i].points = CalcCurvePointAtTime(b[i].t);
                    
                }
                if (gameover==1)
                {
                    MessageBox.Show("GAME OVER");
                    gameover = -1;
                }
                if (!fire)
                {
                    hitball.points.X = LRArm_1[LRArm_1.Count - 1].PE.X;
                    hitball.points.Y = LRArm_1[LRArm_1.Count - 1].PE.Y;
                }
                if(fire)
                {
                    if (Math.Abs(dx) > Math.Abs(dy))
                    {
                        if (xs < xe)
                        {
                            hitball.points.X += Speed;
                            hitball.points.Y += m * Speed;
                            if (hitball.points.X > this.Width || hitball.points.X < 0 || hitball.points.Y > this.Height || hitball.points.Y < 0)
                            {
                                hitball.cl = Colors[rr.Next(0, 4)];
                                fire = false;
                            }
                            for (int i = 0; i < b.Count; i++)
                            {
                                if (hitball.points.X >= b[i].points.X && hitball.points.X <= b[i].points.X + 20 && hitball.points.Y >= b[i].points.Y && hitball.points.Y <= b[i].points.Y + 20 && hitball.cl == b[i].cl)
                                {
                                    
                                    if (i > 0)
                                    {
                                        if (hitball.cl == b[i - 1].cl)
                                        {
                                            b.RemoveAt(i-1);
                                           
                                        }
                                    }
                                    hitball.cl = Colors[rr.Next(0, 4)];
                                    fire = false;
                                    b.RemoveAt(i);
                                }
                            }
                        }
                        else
                        {
                            hitball.points.X -= Speed;
                            hitball.points.Y -= m * Speed;
                            if (hitball.points.X > this.Width || hitball.points.X < 0 || hitball.points.Y > this.Height || hitball.points.Y < 0)
                            {
                                hitball.cl = Colors[rr.Next(0, 4)];
                                fire = false;
                            }
                            for (int i = 0; i < b.Count; i++)
                            {
                                if (hitball.points.X >= b[i].points.X && hitball.points.X <= b[i].points.X + 20 && hitball.points.Y >= b[i].points.Y && hitball.points.Y <= b[i].points.Y + 20 && hitball.cl == b[i].cl)
                                {
                                    
                                    if (i > 0)
                                    {
                                        if (hitball.cl == b[i - 1].cl)
                                        {
                                            b.RemoveAt(i-1);
                                            
                                            
                                        }
                                    }
                                    hitball.cl = Colors[rr.Next(0, 4)];
                                    fire = false;
                                    b.RemoveAt(i);
                                }
                            }
                        }
                    }
                    else
                    {
                        if (ys < ye)
                        {
                            hitball.points.Y += Speed;
                            hitball.points.X += invM * Speed;
                            if (hitball.points.X > this.Width || hitball.points.X < 0 || hitball.points.Y > this.Height || hitball.points.Y < 0)
                            {
                                hitball.cl = Colors[rr.Next(0, 4)];
                                
                                fire = false;
                            }
                            for (int i = 0; i < b.Count; i++)
                            {
                                if (hitball.points.X >= b[i].points.X && hitball.points.X <= b[i].points.X + 20 && hitball.points.Y >= b[i].points.Y && hitball.points.Y <= b[i].points.Y + 20 && hitball.cl == b[i].cl)
                                {
                                    
                                    if (i > 0)
                                    {
                                        if (hitball.cl == b[i - 1].cl)
                                        {
                                            b.RemoveAt(i-1);
                                            
                                            
                                        }
                                    }
                                    hitball.cl = Colors[rr.Next(0, 4)];
                                    fire = false;
                                    b.RemoveAt(i);
                                }
                            }
                        }
                        else
                        {
                            hitball.points.Y -= Speed;
                            hitball.points.X -= invM * Speed;
                            if (hitball.points.X > this.Width || hitball.points.X < 0 || hitball.points.Y > this.Height || hitball.points.Y < 0)
                            {
                                hitball.cl = Colors[rr.Next(0, 4)];
                                fire = false;
                            }
                            for (int i = 0; i < b.Count; i++)
                            {
                                if (hitball.points.X >= b[i].points.X && hitball.points.X <= b[i].points.X + 20 && hitball.points.Y >= b[i].points.Y && hitball.points.Y <= b[i].points.Y + 20 && hitball.cl == b[i].cl)
                                {
                                    
                                    if (i > 0)
                                    {
                                        if (hitball.cl == b[i - 1].cl)
                                        {
                                            b.RemoveAt(i-1);
                                            
                                            
                                        }
                                    }
                                    hitball.cl = Colors[rr.Next(0, 4)];
                                    fire = false;
                                    b.RemoveAt(i);
                                }
                            }
                        }
                    }
                }
            }
            countstop++;
        }

        bool move = false;
        bool start = false;
        
        void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                move = true;
            }
            
        }
        void CreateMyCurve(float x,float y)
        {
             l.LCtrPts.Add(new PointF(x,y));
        }
        int ct = 0;
        PointF firstpoint;
        
        Random rr = new Random();
        ball hitball = new ball();
        Color[] Colors = new Color[4] { Color.Red, Color.Blue, Color.Yellow, Color.Green };
        
        bool fire = false;
        
        void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (!move)
            { 
                CreateMyCurve(e.X, e.Y);
            }
            
            if (!fire && move)
            {
                xs = LRArm_1[LRArm_1.Count - 1].PS.X;
                ys = LRArm_1[LRArm_1.Count - 1].PS.Y;
                xe = LRArm_1[LRArm_1.Count - 1].PE.X;
                ye = LRArm_1[LRArm_1.Count - 1].PE.Y;
                dx = xe - xs;
                dy = ye - ys;
                m = dy / dx;
                invM = dx / dy;
                fire = true;
            }
           
        }
        float dx,dy,m,xs,ys,xe,ye,invM,currX,currY;
        float Speed = 15;
       
        void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            
            dx = e.X - LRArm_1[LRArm_1.Count - 1].PS.X;
            dy = e.Y - LRArm_1[LRArm_1.Count - 1].PS.Y;
            float th = (float)Math.Atan2(dy, dx);

            dx = LRArm_1[LRArm_1.Count - 1].PS.X - center.X;
            dy = LRArm_1[LRArm_1.Count - 1].PS.Y - center.Y;
            float th2 = (float)Math.Atan2(dy, dx);

            for (int i = 0; i < LRArm_1.Count; i++)
            {
                LRArm_1[i].RotateYourSelf(center.X, center.Y, th - th2);
            }

        }

        void Form1_Paint(object sender, PaintEventArgs e)
        {
            DrawDubb(e.Graphics);
        }
        PointF ball1;
        void CreateRightArm(List<LineSeg> L, float XB, float YB)
        {
                LineSeg pnn = new LineSeg();
                pnn.PS = new PointF(XB,YB);
                pnn.PE = new PointF(XB,YB-50);
                L.Add(pnn);
                pnn = new LineSeg();
                pnn.PS = new PointF(XB, YB-50);
                pnn.PE = new PointF(XB+50, YB - 75);
                L.Add(pnn);
                pnn = new LineSeg();
                pnn.PS = new PointF(XB+50, YB-75);
                pnn.PE = new PointF(XB+100, YB - 50);
                L.Add(pnn);
                pnn = new LineSeg();
                pnn.PS = new PointF(XB+100, YB-50);
                pnn.PE = new PointF(XB+100, YB);
                L.Add(pnn);
                pnn = new LineSeg();
                pnn.PS = new PointF(XB+100, YB);
                pnn.PE = new PointF(XB, YB);
                L.Add(pnn);
                pnn = new LineSeg();
                pnn.PS = new PointF(XB + 50, YB - 75);
                pnn.PE = new PointF(XB + 50, YB - 125);
                L.Add(pnn);
                ball1 = new PointF(XB + 50, YB - 125);
                hitball.cl = Colors[rr.Next(0, 4)];
                MessageBox.Show("Draw the curve then press ENTER to start the game");
        }
        PointF center;
        void Form1_Load(object sender, EventArgs e)
        {
            off = new Bitmap(ClientSize.Width, ClientSize.Height);
            CreateRightArm(LRArm_1, this.ClientSize.Width/2-100, this.ClientSize.Height/2+50);
            center = new PointF(this.ClientSize.Width / 2 - 50, this.ClientSize.Height / 2);
        }
        void DrawScene(Graphics g)
        {
            g.Clear(Color.White);
            for (int i = 0; i < LRArm_1.Count; i++)
            {
                LRArm_1[i].DrawYourSelf(g);
            }
            l.DrawYourSelf(g);
            SolidBrush bb = new SolidBrush(hitball.cl);
            g.FillEllipse(bb, hitball.points.X -10, hitball.points.Y -10, 20, 20);
            for (int i = 0; i < b.Count; i++)
            {
                SolidBrush br = new SolidBrush(b[i].cl);
                g.FillEllipse(br, b[i].points.X - 20, b[i].points.Y - 20, 20, 20 );
            }
        }
        void DrawDubb(Graphics g)
        {
            Graphics g2 = Graphics.FromImage(off);
            DrawScene(g2);
            g.DrawImage(off, 0, 0);
        }
    }
}
